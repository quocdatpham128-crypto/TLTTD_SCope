package com.example.tlttd_view

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tlttd_view.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bindData()
        binding.btnUpdateGpa.setOnClickListener {
            updateGpaProcess()
        }
    }
    private fun bindData() {
        with(binding) {
            tvName.text = "Nguyen Van An"
            tvStudentId.text = "MSSV: 22505120005 | Lớp: DD2026"
            tvGpaBadge.text = "GPA: 3.8"
            edtNewGpa.setText("3.8")
        }
    }

    private fun updateGpaProcess() {
        val inputStr = binding.edtNewGpa.text.toString().trim()

        inputStr.toDoubleOrNull()?.let { newGpa ->
            // Khoảng điểm hợp lệ
            if (newGpa in 0.0..4.0) {
                // 'also': Thực hiện ghi Log phụ trợ mà không thay đổi giá trị
                newGpa.also { gpa ->
                    Log.d("STUDENT_LOG", "Cập nhật GPA thành công: $gpa")
                }

                binding.tvGpaBadge.text = "GPA: $newGpa"
                Toast.makeText(this, "Cập nhật GPA thành công!", Toast.LENGTH_SHORT).show()
            } else {
                showGpaError("GPA phải nằm trong khoảng 0.0 - 4.0")
            }
        } ?: run {
            showGpaError("Vui lòng nhập số hợp lệ!")
        }
    }
    private fun showGpaError(errorMessage: String) {
        binding.edtNewGpa.apply {
            error = errorMessage
            requestFocus()
        }
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
    }
}